<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class CreateMahasiswasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('mahasiswas', function (Blueprint $table) {
            $table->id();
            // $table->id()->unsigned();
            $table->string('nama_mahasiswa',50);
            $table->string('alamat_mahasiswa',100);
            $table->string('hp',15);
            $table->string('email',50);
            $table->string('password');
            $table->string('prodi',30);
            $table->timestamps();
        });

        // DB::update("ALTER TABLE mahasiswas AUTO_INCREMENT = 152011513001;");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('mahasiswas');
    }
}
