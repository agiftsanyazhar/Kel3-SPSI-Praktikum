<?php $__env->startSection('container1'); ?>
  <div class="col-lg-6 col-7">
    <h6 class="h2 text-white d-inline-block mb-0">SIPSTA</h6>
    <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
      <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
        <li class="breadcrumb-item"><a href="dashboard-index"><i class="fas fa-home"></i></a></li>
        <li class="breadcrumb-item active"><?php echo e($title); ?></li>
      </ol>
    </nav>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container2'); ?>
<div class="row">
  <div class="col row justify-content-center">
    <div class="card border-0 col-lg-6 col-md-8">
      <div class="card-body px-lg-13 py-lg-5">
        <div class="text-center text-muted mb-4">
          <?php echo e($title); ?>

        </div>
        <form role="form" action="/create-sidang" method="POST" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <div class="form-group">
              <label class="form-control-label" for="input-username" hidden>NIM</label>
              <input class="form-control" placeholder="Nama" type="text" name="nim" value="<?php echo e(auth()->user()->Mahasiswa->id); ?>" hidden>
          </div>
          <div class="form-group">
              <label class="form-control-label" for="input-username">Dosen Pembimbing</label>
              <select class="form-control <?php $__errorArgs = ['nid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nid" required>
                <?php $__currentLoopData = $dosens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($dosen->id); ?>"><?php echo e($dosen->nama_dosen); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
          <div class="form-group">
              <label class="form-control-label" for="input-username">Upload Proposal</label>
              <input class="form-control" type="file" name="proposal" required>
          </div>
          <div class="form-group">
              <label class="form-control-label" for="input-username">Upload KHS</label>
              <input class="form-control" type="file" name="khs" required>
          </div>
          <div class="form-group">
              <label class="form-control-label" for="input-username">Upload TOEFL</label>
              <input class="form-control" type="file" name="toefl" required>
          </div>
          <div class="text-center">
            <button type="submit" class="btn btn-primary mt-4">Daftar Sidang</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\SPSI_Praktikum\resources\views/dashboard/create/sidang.blade.php ENDPATH**/ ?>