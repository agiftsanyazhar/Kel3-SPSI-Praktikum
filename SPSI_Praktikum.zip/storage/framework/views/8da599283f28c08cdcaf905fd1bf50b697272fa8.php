<?php $__env->startSection('container1'); ?>
  <div class="col-lg-6 col-7">
    <h6 class="h2 text-white d-inline-block mb-0">SIPSTA</h6>
    <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
      <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
        <li class="breadcrumb-item"><a href="dashboard-index"><i class="fas fa-home"></i></a></li>
        <li class="breadcrumb-item active"><?php echo e($title); ?></li>
      </ol>
    </nav>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container2'); ?>
<div class="row">
  <div class="col row justify-content-center">
    <div class="card border-0 col-lg-6 col-md-8">
      <div class="card-body px-lg-13 py-lg-5">
        <div class="text-center text-muted mb-4">
          <?php echo e($title); ?>

        </div>
        <form role="form" action="/register" method="POST">
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <div class="input-group input-group-merge input-group-alternative">
              <input class="form-control" placeholder="Nama" type="text" name="Nama" required>
            </div>
          </div>
          <div class="form-group">
            <div class="input-group input-group-merge input-group-alternative">
              <input class="form-control" placeholder="Email" type="email" name="email" required>
            </div>
          </div>
          <div class="form-group">
            <div class="input-group input-group-merge input-group-alternative">
              <input class="form-control" placeholder="HP" type="number" name="hp" required>
            </div>
          </div>
          <div class="form-group">
            <div class="input-group input-group-merge input-group-alternative">
              <input class="form-control" placeholder="Alamat" type="text" name="alamat_dosen" required>
            </div>
          </div>
          <div class="form-group">
            <div class="input-group input-group-merge input-group-alternative">
              <input class="form-control" type="password" placeholder="Password" required/>
            </div>
          </div>
          <div class="text-center">
            <button type="submit" class="btn btn-primary mt-4">Daftar Sidang</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\SPSI_Praktikum\resources\views/dashboard/register-dosen.blade.php ENDPATH**/ ?>